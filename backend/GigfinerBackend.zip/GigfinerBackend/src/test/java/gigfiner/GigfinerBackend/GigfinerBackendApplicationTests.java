package gigfiner.GigfinerBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GigfinerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

package gigfiner.GigfinerBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GigfinerBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GigfinerBackendApplication.class, args);
	}

}
